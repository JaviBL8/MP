#include <iostream>
using namespace std;

int main(){
   int array[5]={1,2,3,4,5};
   cout << array[3] << endl;
}
