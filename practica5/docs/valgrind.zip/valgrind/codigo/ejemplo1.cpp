#include <iostream>
using namespace std;

int main(){
   int array[5];
   cout << array[3] << endl;
}
